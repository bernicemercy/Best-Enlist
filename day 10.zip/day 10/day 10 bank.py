class Account():

    def __init__(self):
        self.balance = 0
        print("Welcome to SBI Banking ")

    def display(self):
        print("Balance",self.balance)
        return self.balance

    def withdraw(self):
        amount = float(input("Amount to withdraw : "))
        if amount < self.balance:
            self.balance -=amount
            print("Amount ",amount," has been withdrawn")
        else:
            print("Not sufficient balace")

    def deposit(self):
        amount = float(input("Amount to deposit : "))
        self.balance += amount
        print("Amount ",amount," has been deposited and your balance is ",self.balance)
        

class InterestAccount(Account):

    def __init__(self,rate=0.1):
        self.rate = rate
        super().__init__()
        self.balance = self.display()
    
    def interest(self):
        self.balance = self.display()
        self.interest = self.balance * self.rate
        print("Interest Amount ",self.interest)


a = InterestAccount()
a.deposit()
a.display()
a.withdraw()
b1 = a.display()
a.interest()

