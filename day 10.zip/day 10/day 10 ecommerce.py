class bill():
    
    def __init__(self,item,price,n):
        self.item = item
        self.n = n
        self.price = price
    def display(self,items,price,n):
        self.items = items
        self.price = price
        self.n = n
        print("ITEM    COST")
        for i in range(self.n):
            print(self.items,"    ",self.cost)

    def total(self,items,price,n):
        self.sum = 0
        self.n = n
        for i in range(self.n):
            self.sum += price[i]

class online(bill):
    def __init__(self,items,price,n):
        super().__init__(items,price,n)
    def show_(self):
        bill.display(items,price,n)
        bill.total(items,price,n)

class cash(bill):
    def __init__(self,items,price,n):
        super().__init__(items,price,n)
    
    def show(self):
        bill.display(items,price,n)
        bill.total(items,price,n)

items = ["a","b","c","d"]
price = [1,2,3,4]
n = len(items)
option = int(input("1 for netbanking and 2 for cash on delivery"))
if option == 1:
    c = online(items,price,n)
    c.show_()
else :
    c = cash(items,price,n)
    c.show()
